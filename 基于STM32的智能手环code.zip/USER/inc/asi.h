#ifndef ASI_H_
#define ASI_H_
#include "stm32f4xx.h"
extern const u8  Aciss_8X16[];
extern u8 Hr[];
extern u8 Bm[];
extern u8 step[];
extern u8 clock[];
extern u8 rt[];

extern u8 tim[];
extern u8 cur_TH[];
extern u8 cur_clk[];
extern u8 lock_sreen[];
extern u8 unlock[];
#endif

