#ifndef BMP_H_
#define BMP_H_
#include "stm32f4xx.h"
extern const u8  Clock_Pic[];
extern const u8  Step_Pic[];
extern const u8 RT_Picture[];
extern const unsigned char HR_Picture[];
extern const unsigned char BM_Picture[];
extern const unsigned char BM_Tip[];
extern const unsigned char HR_Tip[];



extern const unsigned char gImage_20[];
extern const unsigned char gImage_21[];
extern const unsigned char gImage_22[];
extern const unsigned char gImage_23[];
extern const unsigned char gImage_24[];
extern const unsigned char gImage_25[];
extern const unsigned char gImage_26[];
extern const unsigned char gImage_27[];
extern const unsigned char gImage_28[];
extern const unsigned char gImage_29[];
extern const unsigned char gImage_30[];
extern const unsigned char gImage_31[];
extern const unsigned char gImage_32[];

#endif

