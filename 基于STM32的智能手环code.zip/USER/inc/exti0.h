#ifndef __EXTI0_H
#define __EXTI0_H
#include "stm32f4xx.h"


void exti0_init(void);



#endif
