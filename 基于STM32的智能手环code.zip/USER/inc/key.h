#ifndef	_KEY_H
#define _KEY_H

#include "stm32f4xx.h"
#include "tim2.h"
void Key_init(void);
u8 Key_Scan(void);

#endif

