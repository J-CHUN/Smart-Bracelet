#ifndef MENU_H_
#define MENU_H_
#include "stm32f4xx.h"
#include "oled.h"
#include "key.h"
#include "hp6.h"
void Menu_Left(s8 cnt);
void Menu_Right(s8 cnt);

#endif



