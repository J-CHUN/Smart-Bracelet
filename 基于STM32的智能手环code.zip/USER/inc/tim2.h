#ifndef	_TIM2_H
#define _TIM2_H

#include "stm32f4xx.h"

void Delay_ms(u16 ms);
void Delay_us(u16 us);
#endif

