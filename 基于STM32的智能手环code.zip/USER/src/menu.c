#include "menu.h"

void Menu_Left(s8 cnt)
{
	switch(cnt)
	{
		case 0:
		{	
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)Clock_Pic);
			Show_Chinese(2, 65, 4,clock);
			break;
		}
		case 1:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)Step_Pic);
			Show_Chinese(2, 65, 4,step);
			break;
		}
		case 2:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)RT_Picture);
			Show_Chinese(2, 50, 5,rt);
			break;
		}
		case 3:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)BM_Picture);
			Show_Chinese(2, 65, 4,Bm);
			break;
		}
		case 4:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)HR_Picture);
			Show_Chinese(2, 65, 4,Hr);
			break;
		}				
	}
}

void Menu_Right(s8 cnt)
{
	switch(cnt)
	{
		case 0:
		{	
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)Clock_Pic);
			Show_Chinese(2, 65, 4,clock);
			break;
		}
		case 1:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);
			Show_Pic(0, 0, (u8*)Step_Pic);
			Show_Chinese(2, 65, 4,step);
			break;
		}
		case 2:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);
			Show_Pic(0, 0, (u8*)RT_Picture);
			Show_Chinese(2, 50, 5,rt);
			break;
		}
		case 3:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)BM_Picture);
			Show_Chinese(2, 65, 4,Bm);
			break;
		}
		case 4:
		{
			OLED_Clear(0);
			RTC_WakeUpCmd(DISABLE);//�ر�WAKE UP
			Show_Pic(0, 0, (u8*)HR_Picture);
			Show_Chinese(2, 65, 4,Hr);
			break;
		}				
	}
}

